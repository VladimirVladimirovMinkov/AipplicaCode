#pragma once

using namespace System;

namespace APSpec {
	public ref class Class1
	{
		// TODO: Add your methods for this class here.
	};
}
