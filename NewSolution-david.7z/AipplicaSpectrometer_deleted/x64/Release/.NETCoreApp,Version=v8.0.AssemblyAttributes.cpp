#using <mscorlib.dll>
[assembly: System::Runtime::Versioning::TargetFrameworkAttribute(L".NETCoreApp,Version=v8.0", FrameworkDisplayName=L".NET 8.0")];
